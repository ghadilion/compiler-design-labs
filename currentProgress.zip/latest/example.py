a <int> = 0;
data3 <int> = 0;
bar<int> = 10;


data = test;
a = a + 1;

variable<int> = (a+b-2*100+(36));
if(bar < foo){
    bar= bar + 1;
}
else {
    bar= bar - 1;
}

with(i<int> = 2) loop until(i <= n) update(i++) {
    temp<int> = a+b;
}

A<int> = 1;
B<int> = 2;
C<int> = 3;
D<int> = 4;
X<int>;
Y<int> = 6;
Z<int> = 4;


loop while(A < B) {
    if (C < D) {
        X = Y + Z;
    }
}



#
#
#
## The following line is an error but is commented out
## hence the it parses without error
#
#
## with (with(i<int>=1)) loop {}
